burger = document.querySelector('.burger');
navbar = document.getElementById('#nav');
rightnav = document.getElementById('#nav-right');
leftnav = document.getElementById('#nav-left');


burger.addEventListener('click',()=>{
    leftnav.classList.toggle('v-class-resp');
    rightnav.classList.toggle('v-class-resp');
    navbar.classList.toggle('h-nav-resp');

})


gsap.to("#nav",{
    backgroundColor : "rgba(0,0,0,0.5)",
    height: "75px",
    duration: 0.5,
    scrollTrigger:{
        trigger:"#nav",
        scroller :"body",
        // markers: true,
        start:"top -10%",
        end :"top -11%",
        scrub:1

    }
});
gsap.to("#arrow",{
    opacity:1,
    duration: 0.5,
    scrollTrigger:{
        trigger:"#btn2",
        scroller :"body",
        // markers: true,
        start:"top 70%",
        end :"top 75%",
        scrub:1

    }
});

// gsap.to("#nav-right a ",{
//     Color : "#000",
//     height: "75px",
//     duration: 0.5,
//     scrollTrigger:{
//         trigger:"#nav-right a",
//         scroller :"body",
//         markers: true,
//         start:"top -10%",
//         end :"top -11%",
//         scrub:1

//     }
// });